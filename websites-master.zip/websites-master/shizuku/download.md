# Download

[Google Play](https://play.google.com/store/apps/details?id=moe.shizuku.privileged.api)

[GitHub Release](https://github.com/RikkaApps/Shizuku/releases)

[IzzyOnDroid F-Droid Repository](https://apt.izzysoft.de/fdroid/index/apk/moe.shizuku.privileged.api)
