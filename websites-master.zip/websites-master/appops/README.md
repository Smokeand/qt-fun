---
home: true
heroImage: /logo.png
actionText: Download
actionLink: /download.html
secondaryActionText: Learn more
secondaryActionLink: /guide/
features:
- title: Access hidden permission mechanism
  details: Control permissions (partial) by modifying hidden appops settings with App Ops.
- title: Excellent user experience
  details: Provides a beautiful and friendly user interface. App Ops does a lot of effort in many places to reduce the difficulty of use.
- title: Works without root
  details: Provides a variety of working modes that only require adb.
- title: Follow the latest Android system
  details: Support features from newer Android version, even the beta version will be supported in a few days.
- title: Detailed help
  details: Provide detailed help documents.
- title: Provides advanced features
  details: Easy to use with features such as templates, backup and recover.
footer: Copyright © 2019 RikkaApps
---