# How to reset all settings?

1. Switch to app list mode
2. Long press or tap the app icon on the left to enter multi-select mode
3. Three-dot menu - Select all
4. Select "Reset"