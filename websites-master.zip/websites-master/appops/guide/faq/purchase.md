# Purchase or restore problems

## Google Play restore

In most cases, follow the prompts that appear after clicking the purchase. If you still can't solve the problem, please send us an email.