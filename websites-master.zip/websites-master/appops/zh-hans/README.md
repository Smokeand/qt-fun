---
home: true
heroImage: /logo.png
actionText: 立即下载
actionLink: /zh-hans/download.html
secondaryActionText: 了解更多
secondaryActionLink: /zh-hans/guide/
features:
- title: 访问隐藏的权限机制
  details: 借助 App Ops 修改隐藏的 appops 设置来（部分）控制权限。
- title: 优秀的用户体验
  details: 提供美观、友好的用户界面。App Ops 在很多不为人知的地方做出许多努力以降低使用难度。
- title: 无需 root 也可使用
  details: 提供多种只需 adb 的工作模式。
- title: 跟随最新的 Android 系统
  details: 支持新版本 Android 的特性，即使是测试版系统也会在几天内得到支持。
- title: 详细的帮助
  details: 提供详细的帮助文档。
- title: 提供高级功能
  details: 借助模板、备份恢复等功能来方便操作。
footer: Copyright © 2019 RikkaApps
---