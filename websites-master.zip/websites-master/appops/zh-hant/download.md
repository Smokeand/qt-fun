# 下載

[Google Play](https://play.google.com/store/apps/details?id=rikka.appops)

[Coolapk](https://www.coolapk.com/apk/rikka.appops)

[GitHub](https://github.com/RikkaApps/App-Ops-issue-tracker/releases/tag/files)