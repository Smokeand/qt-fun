---
home: true
heroImage: /logo.png
actionText: 立即下載
actionLink: /zh-hant/download.html
secondaryActionText: 瞭解更多
secondaryActionLink: /zh-hant/guide/
features:
- title: 訪問隱藏的權限機制
  details: 藉助 App Ops 修改隱藏的 appops 設定來（部分）控制權限。
- title: 優秀的使用者經驗
  details: 提供美觀、友好的使用者介面。App Ops 在很多不為人知的地方做出許多努力以降低使用難度。
- title: 無需 root 也可使用
  details: 提供多種只需 adb 的工作模式。
- title: 跟隨最新的 Android 系統
  details: 支援新版本 Android 的特性，即使是測試版系統也會在幾天內得到支援。
- title: 詳細的幫助
  details: 提供詳細的幫助文件。
- title: 提供高階功能
  details: 藉助模板、備份恢復等功能來方便操作。
footer: Copyright © 2019 RikkaApps
---