# Contribute online rules

Currently, you need to manually create issues on GitHub. Please follow the steps below.

1. Create a [GitHub](https://github.com/) account if you don't have
2. [Create new issue](https://github.com/RikkaApps/StorageRedirect-assets/issues/new?template=new_rule_json_en.md)
3. Follow the instructions in the issue