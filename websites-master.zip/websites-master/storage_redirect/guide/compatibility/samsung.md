# Samsung

For unknown reasons, on some Samsung devices, execute a 64-bit executable in root user will always get a `Permission denied` when using `exec` functions.

The solution is simple. Install [arm version](./../../download.html) after uninstalling.