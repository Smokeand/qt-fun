# Meizu

If you can use Magisk, you won't run into problems.

If you can't use Magisk, DO NOT enable isolation for the "Settings" app of system (or the [App group](./../advanced/shared_user_id.html) it belongs to).