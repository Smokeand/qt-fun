# Overview

* [Samsung](./samsung.md)
* [Meizu](./meizu.md)
* [Xiaomi (MIUI)](./miui.md)
* Other problems

  * log is disabled

    Check if log is enabled in "Developer Settings". In addition, according to user feedback, log disabled by default on Huawei EMUI. If you are using EMUI, please search how to enable log on EMUI.

    Or the simplest way, using [Enhanced mode](./../enhanced_mode/).
