# Download

**Requirement:** rooted Android 6.0+ device

[Google Play](https://play.google.com/store/apps/details?id=moe.shizuku.redirectstorage) (automatically select architecture)

[Coolapk](https://www.coolapk.com/apk/moe.shizuku.redirectstorage) (arm64 version)

[GitHub](https://github.com/RikkaApps/StorageRedirect-assets/releases) (all architectures, **Samsung users please download arm version from here**)

::: warning
**Samsung users**

Due to some unknown reasons of the Samsung device kernel, **Samsung devices can only use arm version**.
:::