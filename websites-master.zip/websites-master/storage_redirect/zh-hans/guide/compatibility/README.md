# 概览

* [三星](./samsung.md)
* [魅族](./meizu.md)
* [小米（MIUI）](./miui.md)
* 其他

  * log 被关闭问题

    在“开发者设置”中检查 log 是否开启。另外，据用户反馈，在华为 EMUI 上 log 默认被关闭。如果你在使用 EMUI，请自行查询如何在 EMUI 上开启 log。

    或者，最简单的方式，使用 [增强模式](./../enhanced_mode/)。
