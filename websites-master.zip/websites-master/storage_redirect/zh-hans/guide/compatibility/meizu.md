# 魅族

如果你可以使用 Magisk，你不会遇到问题。

如果你不能使用 Magisk，不要为系统的“设置”应用（或其所属的[程序组](./../advanced/shared_user_id.html)）启用隔离。