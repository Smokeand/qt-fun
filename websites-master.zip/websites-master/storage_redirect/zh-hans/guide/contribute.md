# 贡献在线规则

目前需要人工在 GitHub 建立 issue。请按照下面的步骤进行。

1. 如果你没有 [GitHub](https://github.com/) 账号，创建一个
2. [建立新的 issue](https://github.com/RikkaApps/StorageRedirect-assets/issues/new?template=new_rule_json_zh-CN.md)
3. 按照 issue 中的说明填写