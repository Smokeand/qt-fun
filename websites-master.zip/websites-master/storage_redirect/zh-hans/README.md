---
home: true
heroImage: /logo.png
actionText: 下载
actionLink: /zh-hans/download.html
secondaryActionText: 了解更多
secondaryActionLink: /zh-hans/guide/
features:
- title: 再无滥用
  details: 为指定的应用启用隔离，它们将只能访问用户指定的文件夹。
- title: 带回整洁的存储空间
  details: 坏应用不再可以建立一堆文件夹；根据用户设定规则将用有用的文件、媒体等存至规范的文件夹。
- title: 监视文件操作
  details: 监视应用的文件操作，了解其使用了哪些文件。
footer: Copyright © 2023 RikkaApps
---