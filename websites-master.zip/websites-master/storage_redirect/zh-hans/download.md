# 下载

**需求:** 已 root 的 Android 6.0 以上设备

[Google Play](https://play.google.com/store/apps/details?id=moe.shizuku.redirectstorage)（自动选择架构）

[Coolapk](https://www.coolapk.com/apk/moe.shizuku.redirectstorage)（arm64 版本）

[GitHub](https://github.com/RikkaApps/StorageRedirect-assets/releases)（全部架构，**三星用户请在这里下载 arm 版本**）

::: warning
**三星用户**

由于三星设备内核的一些不明原因，**三星设备只能使用 arm 版本**。
:::