---
home: true
heroImage: /logo.png
actionText: Download
actionLink: /download.html
secondaryActionText: Learn more
secondaryActionLink: /guide/
features:
- title: No more abusing
  details: Enable isolation for specified apps, they will only have access to user-specified folders.
- title: Bring back clean storage
  details: Bad apps can never create tons of folders; useful files, media, etc. are saved to standard folders according to user-defined rules.
- title: Monitor file operations
  details: Monitored file operations of apps, learn which file is used.
footer: Copyright © 2020 RikkaApps
---