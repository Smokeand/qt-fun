---
home: true
heroImage: /logo.png
actionText: 下載
actionLink: /zh-hant/download.html
secondaryActionText: 瞭解更多
secondaryActionLink: /zh-hant/guide/
features:
- title: 再無濫用
  details: 為指定的應用程式啟用隔離，它們將只能訪問使用者指定的資料夾。
- title: 帶回整潔的儲存空間
  details: 壞應用程式不再可以建立一堆資料夾；根據使用者設定規則將用有用的檔案、媒體等存至規範的資料夾。
- title: 監視檔案操作
  details: 監視應用程式的檔案操作，瞭解其使用了哪些檔案。
footer: Copyright © 2020 RikkaApps
---