# 下載

**需求:** 已 root 的 Android 6.0 以上裝置

[Google Play](https://play.google.com/store/apps/details?id=moe.shizuku.redirectstorage)（自動選擇架構）

[Coolapk](https://www.coolapk.com/apk/moe.shizuku.redirectstorage)（arm64 版本）

[GitHub](https://github.com/RikkaApps/StorageRedirect-assets/releases)（全部架構，**Samsung 用戶請在這裏下載 arm 版本**）

::: warning
**Samsung 用戶**

由於 Samsung 裝置內核的一些不明原因，**Samsung 裝置只能使用 arm 版本**。
:::