# 概覽

* [Samsung](./samsung.md)
* [Meizu](./meizu.md)
* [Xiaomi (MIUI)](./miui.md)
* 其他

  * log 被關閉問題

    在「開發者設定」中檢查 log 是否開啟。另外，據使用者反饋，在 Huawei EMUI 上 log 預設關閉 log。如果你在使用 EMUI，請自行查詢如何在 EMUI 上開啟 log。

    或者，最簡單的方式，使用 [增強模式](./../enhanced_mode/)。
