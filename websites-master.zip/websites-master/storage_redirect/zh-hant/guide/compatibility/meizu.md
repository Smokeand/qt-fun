# Meizu

如果你可以使用 Magisk，你不會遇到問題。

如果你不能使用 Magisk，不要為系統的「設定」程式（或其所屬的[程式組](./../advanced/shared_user_id.html)）啟用隔離。