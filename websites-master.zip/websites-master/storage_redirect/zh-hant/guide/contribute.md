# 貢獻線上規則

目前需要人工在 GitHub 建立 issue。請按照下面的步驟進行。

1. 如果你沒有 [GitHub](https://github.com/) 賬號，建立一個
2. [建立新的 issue](https://github.com/RikkaApps/StorageRedirect-assets/issues/new?template=new_rule_json_zh-CN.md)
3. 按照 issue 中的說明填寫