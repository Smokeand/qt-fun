# 參與翻譯

RikkaApps 使用自行架設的 Weblate 作為翻譯平臺。目前，我們正在將翻譯移動至該平臺。

1. 進入 <https://weblate.rikka.app/>
2. 透過 GitHub 登入
3. 檢視所有專案 <https://weblate.rikka.app/projects/>，翻譯你想要翻譯的內容

> 對於一些出現在 Android 系統中的名詞，你可以使用這個網站 <https://translations.zhanghai.me/> 搜尋。此網站由 [zhanghai](https://github.com/zhanghai) 開發。