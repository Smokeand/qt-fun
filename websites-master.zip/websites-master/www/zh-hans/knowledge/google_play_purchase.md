# Google Play 购买问题

整个购买过程都发生在 Google Play 中，**应用开发者无法控制它**，因此所有这些解决方案都是经验之谈。

### 多账号问题

如果你登录了多个账号，Play 商店可能会使用错误的账号。应用开发者无法控制。通常使用购买时的账号重新安装即可解决。

如果你用于购买的账号曾经加入了测试计划，你可能需要先退出测试计划。目前测试计划均未开启，因此只能从网页退出。

::: details 测试计划链接

如果你未曾加入测试计划，会看到错误。

- 存储空间隔离：<https://play.google.com/apps/testing/moe.shizuku.redirectstorage>
- AppOps：<https://play.google.com/apps/testing/rikka.appops>
- NoPopping：<https://play.google.com/apps/testing/rikka.nopeeking>

:::

### 使用欺骗程序

诸如“L**** Patcher”之类的欺骗程序会劫持应用程序与 Play 商店之间的连接，最终导致错误。

### 登录到太多设备

Google 可能具有某种风险控制机制，以禁止拥有过多设备的用户使用已购买的内容。

如果您进行出厂重置或刷写第三方 ROM 前没有登出 Google 账号，您的账号中就可能有过多的设备。

检查 [Google 的设备管理页面](https://myaccount.google.com/device-activity) 并删除不存在的设备。

### Code 7

购买记录存储在 Play 商店的缓存中。Code 7 意味着记录丢失了。

通常，清除 Play 商店的缓存可以解决该问题。

### Code 3

当前 Google 账号所在的地区不支持购买。请参阅 [Google 的帮助页面](https://support.google.com/googleplay/android-developer/table/3541286)。

请自行搜索如何确认（改变）账号区域。记住，地区与你的网络环境无关。

### Code 6

购买是一个应用与 Play 商店交互的过程。许多定制系统默认启用一些限制导致该过程受阻。比如，MIUI 需要为 Play 商店允许“在后台显示界面”权限。