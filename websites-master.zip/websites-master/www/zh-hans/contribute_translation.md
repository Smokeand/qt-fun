# 参与翻译

RikkaApps 使用自行托管的 Weblate 作为翻译平台。目前，我们正在将翻译移动至该平台。

1. 进入 <https://weblate.rikka.app/>
2. 通过 GitHub 登录
3. 查看所有项目 <https://weblate.rikka.app/projects/>，翻译你想要翻译的内容

> 对于一些出现在 Android 系统中的名词，你可以使用这个网站 <https://translations.zhanghai.me/> 搜索。此网站由 [zhanghai](https://github.com/zhanghai) 开发。