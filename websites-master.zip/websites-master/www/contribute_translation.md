# Contribute translation

RikkaApps uses self-hosted Weblate as a translation platform. Currently, we are moving the translation to this platform.

1. Go to <https://weblate.rikka.app/>
2. Log in via GitHub
3. View all projects <https://weblate.rikka.app/projects/>, translate what you want to translate

> For some nouns that appear in the Android system, you can use this website <https://translations.zhanghai.me/> to search. This site is developed by [Hai Zhang](https://github.com/zhanghai).